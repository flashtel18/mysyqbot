# MysyqBot evaluation (60 simulated days, 300 breaks, full simulation)

## Main goal: students met in the halls per break

All robots have the same camera (9 cells, no seeing through walls) and walk to any students they see. Only ~40% of each group come out of the room.

| Strategy | Avg students met / break | Trips to an empty hall | Groups spotted by camera |
|---|---|---|---|
| MysyqBot | 8.7 ± 0.3 | 32% | 2.3 |
| No camera Bayes | 8.7 ± 0.3 | 36% | 2.2 |
| Nearest halls | 8.0 ± 0.2 | 36% | 2.2 |
| Random wander | 6.5 ± 0.2 | — (no planned stops) | 2.0 |

MysyqBot meets +35% more students than random wandering and +9% more than nearest-first.

## Per-algorithm checks

| Algorithm | Metric | Ours | Baseline |
|---|---|---|---|
| Bayes (camera) | accuracy of P(group hangs out) > 0.5, halls the camera saw (1082) | 91.9% | timetable prior only: 70.8% |
| Bayes (camera) | Brier score (lower = better) | 0.060 | prior only: 0.202 |
| A* | avg nodes expanded (halls only) | 96.6 | BFS: 280.1 |
| A* | avg path cost | 32.5 | BFS: 33.8 |
| Hill climbing | found the true optimum (300 plans) | 100.0% | exhaustive search |
| Hill climbing | avg score gap to optimum | 0.000 | 0 |
| HMM | mood accuracy (forward filtering) | 68.0% | latest reading only: 68.0% |
| HMM + MDP | avg value of chosen action | 34.09 | latest reading: 33.72, always Motivate: 33.33, knowing true mood: 35.99 |
| Naive Bayes | intent accuracy (leave-one-out) | 79.2% | majority class: ~20% |
