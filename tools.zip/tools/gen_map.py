"""
gen_map.py - turns the QAIRU floor-2 plan (photo of the lobby info screen,
tools/qairu_floor2.png) into the ASCII grid used by the simulation.

Every room / atrium is a polygon in PIXEL coordinates of that photo.
Each 20x20 px square becomes one grid cell (about 1.6 m), then walls are added
automatically around rooms, and doors are placed where the photo shows them.

Run:  python tools/gen_map.py            -> prints the FLOOR_MAP rows
      python tools/gen_map.py --overlay  -> saves tools/overlay.png to check
"""
import sys

X0, Y0, CELL = 60, 95, 20          # pixel origin of cell (0,0) and cell size
W, H = 70, 45

OUTLINE = [(110, 262), (215, 232), (400, 188), (590, 150), (740, 124), (910, 106), (1210, 102),
           (1330, 116), (1400, 158), (1428, 230), (1425, 300), (1420, 390), (1395, 470),
           (1355, 550), (1335, 640), (1315, 740), (1270, 785), (1200, 875), (1100, 942),
           (950, 978), (830, 974), (560, 970), (350, 968), (230, 938), (170, 888), (128, 845),
           (112, 800), (98, 690), (84, 560), (68, 460), (66, 380), (78, 310)]

# room letter -> (room name, polygon). Later rooms are painted over earlier ones.
ROOMS = {
    "a": ("214", [(215, 232), (400, 190), (400, 244), (225, 270)]),
    "b": ("215", [(400, 188), (590, 152), (590, 242), (400, 244)]),
    "c": ("216", [(595, 150), (740, 126), (740, 214), (595, 236)]),
    "d": ("217", [(740, 124), (910, 108), (910, 178), (808, 178), (808, 216), (740, 216)]),
    "e": ("218", [(910, 104), (1205, 102), (1205, 208), (1165, 208), (1165, 178), (910, 178)]),
    "f": ("219", [(1200, 102), (1330, 116), (1400, 158), (1428, 230), (1422, 392), (1195, 372)]),
    "g": ("220", [(1150, 372), (1422, 394), (1380, 508), (1142, 474)]),
    "h": ("221", [(1142, 474), (1380, 508), (1362, 562), (1136, 526)]),
    "i": ("222", [(1136, 526), (1362, 562), (1320, 740), (1272, 782), (1126, 728)]),
    "j": ("223", [(755, 490), (1070, 505), (1070, 662), (755, 642)]),
    "k": ("224", [(836, 698), (1100, 730), (1290, 785), (1200, 875), (1100, 942),
                  (950, 978), (836, 974)]),
    "l": ("225", [(790, 694), (836, 696), (836, 974), (790, 974)]),
    "m": ("226", [(525, 716), (790, 720), (790, 974), (525, 974)]),
    "n": ("200", [(348, 745), (522, 703), (525, 974), (348, 974)]),
    "o": ("201", [(118, 800), (348, 745), (348, 974), (230, 938), (170, 888), (128, 845)]),
    "p": ("202", [(103, 705), (322, 650), (328, 738), (118, 800)]),
    "q": ("203", [(95, 625), (318, 570), (322, 650), (103, 705)]),
    "r": ("207", [(84, 532), (318, 497), (318, 570), (95, 625)]),
    "s": ("204", [(358, 513), (568, 505), (568, 655), (362, 670)]),
    "t": ("213", [(128, 255), (237, 238), (237, 326), (133, 331)]),
    "u": ("212", [(70, 322), (132, 300), (136, 384), (66, 388)]),
    "v": ("209", [(133, 331), (237, 326), (240, 376), (137, 381)]),
    "w": ("211", [(66, 388), (136, 384), (141, 452), (70, 455)]),
    "x": ("210", [(137, 381), (240, 376), (244, 459), (141, 463)]),
    "y": ("208", [(70, 455), (141, 452), (147, 530), (82, 533)]),
    "z": ("206", [(141, 463), (244, 459), (247, 505), (147, 509)]),
    # toilets: the dark blocks on the plan are walls; ~40% of their area are toilets
    "A": ("WC-M", [(285, 372), (427, 372), (427, 478), (285, 478)]),
    "B": ("WC-F", [(427, 372), (570, 372), (570, 478), (427, 478)]),
    "C": ("WC-M2", [(765, 352), (932, 352), (932, 455), (765, 455)]),
    "D": ("WC-F2", [(932, 352), (1100, 352), (1100, 455), (932, 455)]),
}
SOLID = [  # the dark blocks on the plan: solid walls (toilets are cut out of them above)
    [(285, 262), (555, 215), (555, 330), (285, 330)],
    [(285, 330), (570, 305), (570, 478), (285, 478)],
    [(812, 180), (1170, 180), (1170, 248), (812, 248)],
    [(765, 292), (1100, 292), (1100, 455), (765, 455)],
]
STAIRS = [(615, 375), (700, 375), (700, 665), (615, 665)]       # central stairs / escalator
LOUNGE = [(705, 470), (762, 470), (762, 660), (705, 660)]       # sofas next to the stairs
DOCK = (735, 690)                                               # robot dock (near info screen)

# door positions (pixels) - placed on the room wall nearest to this point
DOORS = {
    "214": (245, 262), "215": (575, 242), "216": (630, 236), "217": (765, 214),
    "218": (1185, 208), "219": (1197, 320), "220": (1146, 430), "221": (1139, 500),
    "222": (1130, 600), "223": (1072, 570), "224": (930, 712), "225": (812, 696),
    "226": (580, 718), "200": (440, 722), "201": (338, 748), "202": (325, 700),
    "203": (320, 615), "207": (318, 535), "204": (357, 600), "206": (246, 482),
    "210": (242, 420), "209": (239, 352), "213": (238, 290),
    "WC-M": (356, 482), "WC-F": (498, 482), "WC-M2": (848, 460), "WC-F2": (1016, 460),
}
# 208, 211, 212 have no corridor door on the plan -> offices, not used by the robot


def inside(pt, poly):
    x, y = pt
    res = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            res = not res
        j = i
    return res


def centre(r, c):
    return (X0 + CELL * c + CELL / 2, Y0 + CELL * r + CELL / 2)


def build():
    g = [[" "] * W for _ in range(H)]
    for r in range(H):
        for c in range(W):
            p = centre(r, c)
            if not inside(p, OUTLINE):
                continue
            ch = "."
            if any(inside(p, v) for v in SOLID):
                ch = "#"
            if inside(p, STAIRS):
                ch = "X"
            if inside(p, LOUNGE):
                ch = "~"
            for letter, (_, poly) in ROOMS.items():
                if inside(p, poly):
                    ch = letter
            g[r][c] = ch
    base = [row[:] for row in g]

    def around(r, c):
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = r + dr, c + dc
            yield (base[nr][nc] if 0 <= nr < H and 0 <= nc < W else " ")

    # walls: building edge, and room edges (between two rooms only one side becomes wall)
    for r in range(H):
        for c in range(W):
            ch = base[r][c]
            if ch == " ":
                continue
            nbs = list(around(r, c)) + [
                base[r + a][c + b] if 0 <= r + a < H and 0 <= c + b < W else " "
                for a in (-1, 1) for b in (-1, 1)]
            if ch in ROOMS:
                if any(n != ch and (n not in ROOMS or n < ch) for n in around(r, c)):
                    g[r][c] = "#"
            elif " " in nbs:
                g[r][c] = "#"

    def is_hall(rc):
        return g[rc[0]][rc[1]] in ".~"

    # remove small hall pockets that are not connected to the main corridor
    start = min(((centre(r, c)[0] - DOCK[0]) ** 2 + (centre(r, c)[1] - DOCK[1]) ** 2, (r, c))
                for r in range(H) for c in range(W) if g[r][c] == ".")[1]
    seen, stack = {start}, [start]
    while stack:
        r, c = stack.pop()
        for nr, nc in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
            if 0 <= nr < H and 0 <= nc < W and (nr, nc) not in seen and g[nr][nc] in ".~X":
                seen.add((nr, nc))
                stack.append((nr, nc))
    for r in range(H):
        for c in range(W):
            if g[r][c] in ".~" and (r, c) not in seen:
                g[r][c] = "#"

    for name, (px, py) in DOORS.items():
        letter = next(k for k, v in ROOMS.items() if v[0] == name)
        best = None
        for r in range(1, H - 1):
            for c in range(1, W - 1):
                if g[r][c] != "#":
                    continue
                nb = [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]
                if any(g[a][b] == letter for a, b in nb) and any(is_hall(x) for x in nb):
                    x, y = centre(r, c)
                    d = (x - px) ** 2 + (y - py) ** 2
                    if best is None or d < best[0]:
                        best = (d, r, c)
        if best is None:
            raise SystemExit(f"no door position found for room {name}")
        g[best[1]][best[2]] = "+"

    # dock = hall cell nearest to DOCK
    best = min(((centre(r, c)[0] - DOCK[0]) ** 2 + (centre(r, c)[1] - DOCK[1]) ** 2, r, c)
               for r in range(H) for c in range(W) if g[r][c] == ".")
    g[best[1]][best[2]] = "S"
    return ["".join(row) for row in g]


def overlay(rows, src="tools/qairu_floor2.png", out="tools/overlay.png"):
    from PIL import Image, ImageDraw
    im = Image.open(src).convert("RGBA")
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    colors = {"#": (255, 255, 255, 150), "+": (255, 140, 0, 230), ".": (0, 255, 120, 70),
              "~": (255, 210, 0, 110), "V": (0, 0, 0, 120), "X": (255, 0, 255, 140),
              "S": (0, 255, 0, 255)}
    for r, row in enumerate(rows):
        for c, ch in enumerate(row):
            col = colors.get(ch, (60, 120, 255, 60) if ch.isalpha() else None)
            if col:
                x, y = X0 + CELL * c, Y0 + CELL * r
                d.rectangle([x, y, x + CELL - 1, y + CELL - 1], fill=col)
    Image.alpha_composite(im, layer).save(out)
    print("saved", out)


if __name__ == "__main__":
    rows = build()
    if "--overlay" in sys.argv:
        overlay(rows)
    for row in rows:
        print(f'    "{row}",')
