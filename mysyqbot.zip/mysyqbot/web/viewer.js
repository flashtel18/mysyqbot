// viewer.js - draws the MysyqBot simulation in 3D with plain WebGL (no libraries).
// All AI runs in Python (server3d.py); this file only asks the server for the
// current state ~10 times per second and renders it.
"use strict";
(() => {
  const $ = (id) => document.getElementById(id);

  // ------------------------------------------------------------------ math
  const norm = (v) => { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

  function perspective(fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    return [f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0];
  }
  function lookAt(e, t, up) {
    const z = norm([e[0] - t[0], e[1] - t[1], e[2] - t[2]]);
    const x = norm(cross(up, z));
    const y = cross(z, x);
    return [x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0,
      -dot(x, e), -dot(y, e), -dot(z, e), 1];
  }
  function mul(a, b) {
    const o = new Array(16).fill(0);
    for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++)
      for (let k = 0; k < 4; k++) o[c * 4 + r] += a[k * 4 + r] * b[c * 4 + k];
    return o;
  }
  const xform = (m, p) => [
    m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13],
    m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14], m[3] * p[0] + m[7] * p[1] + m[11] * p[2] + m[15]];

  // --------------------------------------------------------------- colours
  const hex = (h) => [parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255];
  const LIGHT = norm([-0.45, 1.0, 0.35]);
  function shade(col, n) {
    const d = Math.max(0, dot(n, LIGHT));
    const k = 0.58 + 0.42 * d;
    return [col[0] * k, col[1] * k, col[2] * k];
  }
  const C = {
    hall1: hex("#ece7da"), hall2: hex("#e5dfcf"), room: hex("#b7cdf2"), office: hex("#d3d9e4"),
    door: hex("#b9855a"), wc1: hex("#bfe6e0"), wc2: hex("#a9dbd3"), lounge: hex("#dcae73"), dock: hex("#7fc8a9"),
    wall: hex("#f4f6fb"), wallTop: hex("#aab4cc"), outer: hex("#e3e8f3"),
    voidFloor: hex("#1a2448"), voidSide: hex("#3a4878"), rail: hex("#9cc3ec"),
    stair1: hex("#d4dbea"), stair2: hex("#bcc6db"), sofa: hex("#6c4f9e"), screen: hex("#2d6cdf"),
    skin: hex("#f0c8a0"), hair: hex("#2b2118"),
    catBody: hex("#f28c28"), catHead: hex("#f6a24c"), catDark: hex("#3d2c1d"), catPink: hex("#ff8fa3"),
    plan: hex("#f28c28"), guide: hex("#2f9e6e"),
    vision: hex("#19b8e6"), belief: hex("#ff7a3d"), astar: hex("#b48cff"), seen: hex("#ffe14d"),
  };
  const WALL_IN = 0.95, WALL_OUT = 1.3, VOID_D = 2.6;

  // ------------------------------------------------------------ mesh builder
  class Mesh {
    constructor() { this.v = []; }
    tri(a, b, c, col, alpha = 1) {
      for (const p of [a, b, c]) this.v.push(p[0], p[1], p[2], col[0], col[1], col[2], alpha);
    }
    quad(a, b, c, d, col, n, alpha = 1) {
      const k = n ? shade(col, n) : col;
      this.tri(a, b, c, k, alpha); this.tri(a, c, d, k, alpha);
    }
    box(x0, x1, y0, y1, z0, z1, col, top) {
      this.quad([x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1], top || col, [0, 1, 0]);
      this.quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], col, [0, 0, 1]);
      this.quad([x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [x1, y0, z0], col, [0, 0, -1]);
      this.quad([x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1], col, [1, 0, 0]);
      this.quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], col, [-1, 0, 0]);
    }
    prism(cx, cz, r, y0, y1, col, top, sides = 8) {
      for (let i = 0; i < sides; i++) {
        const a0 = (i / sides) * Math.PI * 2, a1 = ((i + 1) / sides) * Math.PI * 2;
        const p0 = [cx + Math.cos(a0) * r, cz + Math.sin(a0) * r], p1 = [cx + Math.cos(a1) * r, cz + Math.sin(a1) * r];
        const am = (a0 + a1) / 2;
        this.quad([p0[0], y0, p0[1]], [p1[0], y0, p1[1]], [p1[0], y1, p1[1]], [p0[0], y1, p0[1]], col, [Math.cos(am), 0, Math.sin(am)]);
        this.tri([cx, y1, cz], [p1[0], y1, p1[1]], [p0[0], y1, p0[1]], shade(top || col, [0, 1, 0]));
      }
    }
    // box in the robot's local frame: u = right, w = forward
    obox(o, a, u0, u1, y0, y1, w0, w1, col, top) {
      const R = [Math.cos(a), 0, -Math.sin(a)], F = [Math.sin(a), 0, Math.cos(a)];
      const P = (u, y, w) => [o[0] + R[0] * u + F[0] * w, y, o[2] + R[2] * u + F[2] * w];
      const nF = F, nB = [-F[0], 0, -F[2]], nR = R, nL = [-R[0], 0, -R[2]];
      this.quad(P(u0, y1, w0), P(u1, y1, w0), P(u1, y1, w1), P(u0, y1, w1), top || col, [0, 1, 0]);
      this.quad(P(u0, y0, w1), P(u1, y0, w1), P(u1, y1, w1), P(u0, y1, w1), col, nF);
      this.quad(P(u0, y0, w0), P(u0, y1, w0), P(u1, y1, w0), P(u1, y0, w0), col, nB);
      this.quad(P(u1, y0, w0), P(u1, y1, w0), P(u1, y1, w1), P(u1, y0, w1), col, nR);
      this.quad(P(u0, y0, w0), P(u0, y0, w1), P(u0, y1, w1), P(u0, y1, w0), col, nL);
      return P;
    }
  }

  // ------------------------------------------------------------------ WebGL
  const canvas = $("gl"), overlay = $("overlay"), ctx = overlay.getContext("2d");
  const gl = canvas.getContext("webgl", { antialias: true, alpha: true });
  if (!gl) { fail("Your browser does not support WebGL. Try Chrome or Edge."); return; }
  const VS = `attribute vec3 aPos; attribute vec4 aCol; uniform mat4 uMVP; varying vec4 vCol;
    void main(){ gl_Position = uMVP * vec4(aPos, 1.0); vCol = aCol; }`;
  const FS = `precision mediump float; varying vec4 vCol; void main(){ gl_FragColor = vCol; }`;
  function compile(type, src) {
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
    return s;
  }
  const prog = gl.createProgram();
  gl.attachShader(prog, compile(gl.VERTEX_SHADER, VS));
  gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FS));
  gl.linkProgram(prog);
  gl.useProgram(prog);
  const aPos = gl.getAttribLocation(prog, "aPos"), aCol = gl.getAttribLocation(prog, "aCol");
  const uMVP = gl.getUniformLocation(prog, "uMVP");
  gl.enableVertexAttribArray(aPos); gl.enableVertexAttribArray(aCol);
  gl.enable(gl.DEPTH_TEST);
  gl.clearColor(0, 0, 0, 0);

  function makeBuffer() { return { buf: gl.createBuffer(), n: 0 }; }
  function upload(b, mesh, usage) {
    gl.bindBuffer(gl.ARRAY_BUFFER, b.buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(mesh.v), usage);
    b.n = mesh.v.length / 7;
  }
  function draw(b) {
    if (!b.n) return;
    gl.bindBuffer(gl.ARRAY_BUFFER, b.buf);
    gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 28, 0);
    gl.vertexAttribPointer(aCol, 4, gl.FLOAT, false, 28, 12);
    gl.drawArrays(gl.TRIANGLES, 0, b.n);
  }
  const staticBuf = makeBuffer(), dynBuf = makeBuffer(), alphaBuf = makeBuffer();

  // ------------------------------------------------------------ static scene
  let MAP = null, letterToRoom = {}, labelSpots = [];
  function buildStatic(map) {
    MAP = map;
    letterToRoom = {};
    for (const [name, r] of Object.entries(map.rooms)) letterToRoom[r.letter] = name;
    const g = map.grid, H = map.H, W = map.W, m = new Mesh();
    const at = (r, c) => (r < 0 || c < 0 || r >= H || c >= W) ? " " : g[r][c];
    const isOuter = (r, c) => {
      for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) if (at(r + a, c + b) === " ") return true;
      return false;
    };
    const stairRows = map.exits.map((p) => p[0]);
    const sMin = Math.min(...stairRows), sMax = Math.max(...stairRows);

    for (let r = 0; r < H; r++) {
      // walls: merge runs of wall cells with the same height into one box
      let c = 0;
      while (c < W) {
        if (g[r][c] !== "#") { c++; continue; }
        const h = isOuter(r, c) ? WALL_OUT : WALL_IN;
        let c2 = c;
        while (c2 + 1 < W && g[r][c2 + 1] === "#" && (isOuter(r, c2 + 1) ? WALL_OUT : WALL_IN) === h) c2++;
        m.box(c - 0.5, c2 + 0.5, 0, h, r - 0.5, r + 0.5, h === WALL_OUT ? C.outer : C.wall, C.wallTop);
        c = c2 + 1;
      }
      for (c = 0; c < W; c++) {
        const ch = g[r][c];
        const x0 = c - 0.5, x1 = c + 0.5, z0 = r - 0.5, z1 = r + 0.5;
        const floor = (col, y = 0) => m.quad([x0, y, z0], [x1, y, z0], [x1, y, z1], [x0, y, z1], col, [0, 1, 0]);
        if (ch === " " || ch === "#") continue;
        if (ch === "V" || ch === "X") {
          // stair well (and any opening to floor 1): floor deep below, side walls, glass rail around
          let topY = -VOID_D;
          if (ch === "X") {
            const idx = r - sMin, n = sMax - sMin + 1;
            topY = -VOID_D * (idx + 0.6) / (n + 0.6);
            const col = idx % 2 ? C.stair2 : C.stair1;
            m.box(x0, x1, -VOID_D, topY, z0, z1, col, col);
          } else floor(C.voidFloor, -VOID_D);
          const nbs = [[r - 1, c, [x0, z0], [x1, z0], [0, 0, 1]], [r + 1, c, [x1, z1], [x0, z1], [0, 0, -1]],
            [r, c - 1, [x0, z1], [x0, z0], [1, 0, 0]], [r, c + 1, [x1, z0], [x1, z1], [-1, 0, 0]]];
          for (const [nr, nc, p, q, n] of nbs) {
            const o = at(nr, nc);
            if (o === ch) continue;
            if (ch === "X" && o === "X") continue;
            m.quad([p[0], 0, p[1]], [q[0], 0, q[1]], [q[0], topY, q[1]], [p[0], topY, p[1]], C.voidSide, n);
            const entry = ch === "X" && nr === sMin - 1;
            if (".~S+".includes(o) && !entry) {            // glass railing on the hall side
              const t = 0.05, ex = n[0] * -t, ez = n[2] * -t;
              m.box(Math.min(p[0], q[0], p[0] + ex), Math.max(p[0], q[0], p[0] + ex), 0, 0.55,
                Math.min(p[1], q[1], p[1] + ez), Math.max(p[1], q[1], p[1] + ez), C.rail, C.rail);
            }
          }
          continue;
        }
        if (ch === "." || ch === "S") floor((r + c) % 2 ? C.hall1 : C.hall2);
        else if (ch === "~") {
          floor(C.lounge);
          if (r % 3 === 0) {                                  // sofas in the lounge
            m.box(c - 0.38, c + 0.38, 0, 0.26, r - 0.42, r + 0.42, C.sofa);
            m.box(c + 0.22, c + 0.4, 0.26, 0.55, r - 0.42, r + 0.42, C.sofa);
          }
        } else if (ch === "+") {
          floor(C.door);
          m.box(x0, x1, WALL_IN * 0.78, WALL_IN, z0, z1, C.wall, C.wallTop);   // lintel
        } else {
          const name = letterToRoom[ch];
          const info = name && map.rooms[name];
          floor(info && info.toilet ? ((r + c) % 2 ? C.wc1 : C.wc2) : info && info.office ? C.office : C.room);
        }
      }
    }
    // robot dock: charging pad + the big info screen behind it
    const [dr, dc] = map.dock;
    m.box(dc - 0.45, dc + 0.45, 0, 0.04, dr - 0.45, dr + 0.45, C.dock);
    m.box(dc - 1.6, dc + 1.6, 0.35, 1.45, dr - 0.62, dr - 0.52, C.screen, C.screen);
    upload(staticBuf, m, gl.STATIC_DRAW);

    // labels for the overlay
    labelSpots = [];
    for (const [name, r] of Object.entries(map.rooms))
      labelSpots.push({ name, title: r.title || name, x: r.center[1], z: r.center[0], office: r.office, toilet: r.toilet });
    const comps = components(g, "V");
    for (const comp of comps) if (comp.length > 20) {
      const cr = comp.reduce((s, p) => s + p[0], 0) / comp.length, cc = comp.reduce((s, p) => s + p[1], 0) / comp.length;
      labelSpots.push({ name: "atrium", x: cc, z: cr, y: -VOID_D, misc: true });
    }
    const er = map.exits.reduce((s, p) => s + p[0], 0) / map.exits.length;
    const ec = map.exits.reduce((s, p) => s + p[1], 0) / map.exits.length;
    labelSpots.push({ name: "stairs ↓", x: ec, z: er, y: -1, misc: true });
    labelSpots.push({ name: "info screen", x: map.dock[1], z: map.dock[0] - 0.6, y: 1.6, misc: true });
    buildLegend(map);
  }
  function components(g, ch) {
    const seen = new Set(), out = [];
    for (let r = 0; r < g.length; r++) for (let c = 0; c < g[r].length; c++) {
      if (g[r][c] !== ch || seen.has(r + "," + c)) continue;
      const comp = [], st = [[r, c]]; seen.add(r + "," + c);
      while (st.length) {
        const [a, b] = st.pop(); comp.push([a, b]);
        for (const [x, y] of [[a + 1, b], [a - 1, b], [a, b + 1], [a, b - 1]])
          if (g[x] && g[x][y] === ch && !seen.has(x + "," + y)) { seen.add(x + "," + y); st.push([x, y]); }
      }
      out.push(comp);
    }
    return out;
  }
  function buildLegend(map) {
    $("legend").innerHTML = map.group_order.map((g) => `<span><i style="background:${map.groups[g]}"></i>${g}</span>`).join("")
      + `<span><i style="background:#f28c28"></i>MysyqBot</span><span><i style="background:#ffe14d"></i>spotted by camera</span>`
      + `<span><i style="background:rgba(242,140,40,.35)"></i>talk zone</span>`
      + `<span><i style="background:#f28c28;border-radius:2px;height:4px"></i>planned tour</span>`
      + `<span><i style="background:#2f9e6e;border-radius:2px;height:4px"></i>guide route</span>`;
  }

  // ----------------------------------------------------------------- camera
  const cam = { yaw: -0.5, pitch: 0.95, dist: 80, target: [35, 0, 22], follow: false };
  let viewMVP = null, cssW = 1, cssH = 1;
  function resetView(top) {
    cam.follow = false; $("btnFollow").classList.remove("on");
    cam.target = [MAP ? MAP.W / 2 - 0.5 : 35, 0, MAP ? MAP.H / 2 + 3 : 22];
    cam.yaw = top ? 0 : -0.5; cam.pitch = top ? 1.5 : 0.95; cam.dist = top ? 72 : 80;
  }
  let drag = null;
  canvas.addEventListener("contextmenu", (e) => e.preventDefault());
  canvas.addEventListener("pointerdown", (e) => { drag = { x: e.clientX, y: e.clientY, pan: e.button === 2 || e.shiftKey }; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener("pointerup", () => { drag = null; });
  canvas.addEventListener("pointermove", (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    drag.x = e.clientX; drag.y = e.clientY;
    if (drag.pan) {
      const k = cam.dist * 0.0016, R = [Math.cos(cam.yaw), 0, -Math.sin(cam.yaw)], F = [-Math.sin(cam.yaw), 0, -Math.cos(cam.yaw)];
      cam.target[0] += -R[0] * dx * k + F[0] * dy * k;
      cam.target[2] += -R[2] * dx * k + F[2] * dy * k;
      cam.follow = false; $("btnFollow").classList.remove("on");
    } else {
      cam.yaw -= dx * 0.006;
      cam.pitch = clamp(cam.pitch + dy * 0.005, 0.18, 1.53);
    }
  });
  canvas.addEventListener("wheel", (e) => { e.preventDefault(); cam.dist = clamp(cam.dist * Math.exp(e.deltaY * 0.001), 6, 140); }, { passive: false });

  // ------------------------------------------------------------- sim state
  let prev = null, cur = null, logCount = 0, speed = 15, paused = false, lastPoll = performance.now();
  let heading = 0, failures = 0, astarKnown = -1, astarCells = [], astarRecv = 0, lastEvent = null, explainKey = "";
  const posMap = (st) => { const m = new Map(); for (const s of st.students) m.set(s[0], s); return m; };

  async function poll() {
    const now = performance.now();
    const real = Math.min((now - lastPoll) / 1000, 0.5);
    lastPoll = now;
    let mult = 1;
    if (cur && cur.idle && cur.next_break != null && cur.next_break - cur.t > 40) mult = 15;
    let dt = paused ? 0 : real * speed * mult;
    if (mult > 1) dt = Math.min(dt, cur.next_break - cur.t - 20);   // never jump over the start of a break
    try {
      const res = await fetch(`/api/state?dt=${dt.toFixed(3)}&since=${logCount}&av=${astarKnown}`);
      const st = await res.json();
      failures = 0;
      st.arrive = performance.now();
      st.map = posMap(st);
      if (st.astar_cells) { astarCells = st.astar_cells; astarKnown = st.astar_id; astarRecv = performance.now(); }
      st.seenSet = new Set(st.seen);
      prev = cur || st; cur = st;
      const dx = cur.robot.c - prev.robot.c, dz = cur.robot.r - prev.robot.r;
      if (Math.hypot(dx, dz) > 0.01) cur.heading = Math.atan2(dx, dz); else cur.heading = prev.heading ?? 0;
      onState(st);
    } catch (err) {
      console.error(err);
      if (++failures > 5) fail("Lost connection to the simulation.<br>Start it with <b>python server3d.py</b> and reload this page.");
    }
    setTimeout(poll, 90);
  }

  function addLog(lines) {
    const el = $("log");
    const atBottom = el.scrollTop + el.clientHeight > el.scrollHeight - 30;
    for (const ln of lines) {
      const span = document.createElement("div");
      span.textContent = ln || " ";
      if (ln.startsWith("===")) span.className = "h";
      else if (/^\s*\[/.test(ln)) span.className = "alg";
      else if (ln.includes("ASKS")) span.className = "ask";
      else if (ln.includes("says:") || ln.includes("answer:")) span.className = "say";
      el.appendChild(span);
    }
    while (el.childNodes.length > 700) el.removeChild(el.firstChild);
    if (atBottom) el.scrollTop = el.scrollHeight;
  }
  function onState(st) {
    addLog(st.log);
    logCount = st.log_total;
    $("clock").textContent = st.clock;
    $("mode").textContent = "Mon 16 Nov · " + st.mode;
    const s = st.stats;
    $("stats").innerHTML = `breaks <b>${s.breaks}</b> · groups spotted by camera <b>${s.spotted}</b> · groups met <b>${s.visits}</b>`
      + ` · empty halls checked <b>${s.empty}</b> · students met <b>${s.reached}</b> · walked up by themselves <b>${s.came_by_themselves}</b>`
      + ` · questions <b>${s.questions}</b>`;
    renderChat(st.chat);
    const ex = st.explain;
    $("phase").textContent = PHASES[ex.phase] || ex.phase.toUpperCase();
    $("thoughtText").textContent = ex.thought;
    for (const a of ALGO) $("chip-" + a.key).classList.toggle("on", ex.active.includes(a.key));
    const key = JSON.stringify([ex, st.seen.length]);
    if (key !== explainKey) { explainKey = key; renderExplain(ex, st); }
    if (lastEvent !== null && ex.event > lastEvent && $("pauseOnDecision").checked
        && ["plan", "decide", "answer"].includes(ex.event_kind)) {
      setPaused(true);
      $("pauseBanner").hidden = false;
      const first = document.getElementById("card-" + ex.active[ex.active.length - 1]);
      if (first) first.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
    lastEvent = ex.event;
  }

  let chatSeen = 0;
  function renderChat(chat) {
    if (!chat || !chat.length) return;
    const last = chat[chat.length - 1].n;
    if (last === chatSeen) return;
    const fresh = last - chatSeen;
    chatSeen = last;
    $("chatList").innerHTML = chat.slice().reverse().map((m, i) => `<div class="qa${i < fresh ? " new" : ""}">
      <div class="q"><span class="muted">${m.clock}</span> <span class="who">${m.who === "You" ? "You" : "🎓 " + esc(m.who)}:</span> “${esc(m.text)}”</div>
      <span class="tag">Naive Bayes → ${esc(m.intent)} ${Math.round(m.conf * 100)}%</span>
      <div class="a"><b>🐱 MysyqBot:</b> ${esc(m.reply)}</div></div>`).join("");
    $("chat").scrollTop = 0;
  }

  // ------------------------------------------------------ explanation UI
  const ALGO = [
    { key: "vision", name: "Camera", wk: "perception" },
    { key: "bayes", name: "Bayes", wk: "Week 6" },
    { key: "astar", name: "A* search", wk: "Week 2" },
    { key: "hill", name: "Hill climbing", wk: "Week 3" },
    { key: "hmm", name: "HMM", wk: "Week 7" },
    { key: "mdp", name: "MDP", wk: "Week 5" },
    { key: "nb", name: "Naive Bayes", wk: "Week 8" },
  ];
  const PHASES = { patrol: "PATROL", plan: "PLANNING", tour: "CHECKING A HALL", approach: "GOING TO STUDENTS",
    interact: "TALKING", answer: "ANSWERING" };
  const esc = (x) => String(x).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const pct = (x) => Math.round(x * 100) + "%";
  function bar(label, value, max, opts = {}) {
    const w = max > 0 ? clamp(value / max, 0, 1) * 100 : 0;
    const mark = opts.mark != null ? `<div class="mark" style="left:${clamp(opts.mark / max, 0, 1) * 100}%"></div>` : "";
    return `<div class="bar"><div class="lbl" title="${esc(label)}">${esc(label)}</div><div class="track">`
      + `<div class="fill${opts.hot ? " hot" : ""}" style="width:${w}%"></div>${mark}</div>`
      + `<div class="val">${esc(opts.text ?? value)}</div></div>`;
  }
  function card(a, active, body) {
    return `<section class="card${active ? " on" : ""}" id="card-${a.key}"><h3>${a.name} <span class="wk">${a.wk}</span>`
      + `${active ? '<span class="live">ACTIVE NOW</span>' : ""}</h3>${body}</section>`;
  }
  function renderExplain(ex, st) {
    const on = (k) => ex.active.includes(k);
    const parts = [];
    // camera
    parts.push(card(ALGO[0], on("vision"), `<div class="why">The robot <b>cannot see through walls</b> and does not know where students are.
      Its camera sees about ${MAP.vision_r} cells (≈14 m) along the halls - not around corners, not through walls, never inside classrooms.
      If it spots students, near or far, it walks to them.</div>
      <div class="kv">Students in view right now: <b>${st.seen.length}</b> · camera area is the <span style="color:#6fe3ff">cyan</span> zone in 3D</div>`));
    // bayes
    const bz = ex.bayes || {};
    let bb = `<div class="why">Which halls probably have students? <b>Prior</b> from the timetable (late teacher, lunch, last class…),
      <b>updated</b> every time the camera looks at a hall.</div>
      <div class="formula">P(H | obs) = P(obs|H)·P(H) / [ P(obs|H)·P(H) + P(obs|¬H)·P(¬H) ]
H = "this group hangs out in the hall"</div>`;
    if (bz.last) {
      const L = bz.last;
      bb += `<div class="kv">Last look: hall of <b>${L.room}</b> (${L.group}), ${L.since}s after class → <b>${L.obs}</b></div>
        <div class="formula">P(H|${L.obs}) = ${L.l_h}·${L.prior} / (${L.l_h}·${L.prior} + ${L.l_n}·${(1 - L.prior).toFixed(3)}) = <b>${L.post}</b></div>`;
    }
    if (bz.zones && bz.zones.length) {
      bb += `<div class="bars">` + bz.zones.map((z) => bar(`${z.room} ${z.group}`, z.p, 1,
        { mark: z.prior, hot: z.p >= 0.5, text: pct(z.p) })).join("") + `</div>
        <div class="muted">bar = belief now · white line = timetable prior · orange tint in 3D</div>`;
    } else bb += `<div class="muted">No break right now - priors appear when lectures end.</div>`;
    parts.push(card(ALGO[1], on("bayes"), bb));
    // A*
    const A = ex.astar;
    let ab = `<div class="why">Fastest route <b>through the halls only</b> (the robot never enters rooms). The crowded lounge costs 3×.</div>
      <div class="formula">f(n) = g(n) + h(n)     h = |Δrow| + |Δcol|  (Manhattan, admissible → optimal)</div>`;
    if (A) {
      const mx = Math.max(A.expanded, A.bfs_expanded || 0, 1);
      ab += `<div class="kv">Goal: <b>${esc(A.goal)}</b> · ${A.cells} cells · ≈ <b>${A.seconds} s</b></div>
        <div class="bars">${bar("A* checked", A.expanded, mx, { hot: true, text: A.expanded + " cells" })}
        ${A.bfs_expanded ? bar("BFS would check", A.bfs_expanded, mx, { text: A.bfs_expanded + " cells" }) : ""}</div>
        <div class="muted">purple tiles in 3D = cells A* expanded</div>`;
    }
    parts.push(card(ALGO[2], on("astar"), ab));
    // hill climbing
    const Hc = ex.hill;
    let hb = `<div class="why">A break is 10 min - the robot cannot check every hall. Which halls, in which order?</div>
      <div class="formula">score = Σ size × 40% × exam priority × [P·linger(t) + (1−P)·quick(t)]
neighbours: add / remove / swap / replace a hall · 8 random restarts</div>`;
    if (Hc) {
      hb += `<div class="steps">` + Hc.trace.map((s) => `<div><span>${esc(s[0])} → ${esc(s[1].join(" › ") || "(empty)")}</span><span>${s[2].toFixed(1)}</span></div>`).join("")
        + `<div class="best"><span>best tour → ${esc(Hc.best.join(" › ") || "none, just patrol")}</span><span>${Hc.score.toFixed(1)}</span></div></div>
        <div class="kv" style="margin-top:5px">time left: <b>${Hc.budget}s</b>${Hc.skipped.length ? ` · skipped: <b>${Hc.skipped.join(", ")}</b> (not worth the time)` : ""}</div>
        <div class="muted">restart scores: ${Hc.all_scores.map((x) => x.toFixed(1)).join(" · ")} · numbered stops in 3D</div>`;
    } else hb += `<div class="muted">Waiting for the next break.</div>`;
    parts.push(card(ALGO[3], on("hill"), hb));
    // HMM
    const M = ex.hmm;
    let mb = `<div class="why">A group's mood is <b>hidden</b>. The robot only has noisy activity readings after each class today.</div>
      <div class="formula">forward:  b(s') ∝ P(obs|s') · Σ_s P(s'|s) b(s)     Viterbi: most likely mood sequence</div>`;
    if (M) {
      mb += `<div class="kv">Group <b>${M.group}</b> · readings today:</div><div class="tokens">${M.readings.map((r) => `<span>${r}</span>`).join("")}</div>
        <div class="bars">${Object.entries(M.belief).map(([k, v]) => bar(k, v, 1, { hot: v === Math.max(...Object.values(M.belief)), text: pct(v) })).join("")}</div>
        <div class="chain">Viterbi: ${M.viterbi.map((v) => `<span>${v}</span>`).join(" → ")}</div>`;
    } else mb += `<div class="muted">Waiting for the robot to meet a group.</div>`;
    parts.push(card(ALGO[4], on("hmm"), mb));
    // MDP
    const D = ex.mdp;
    let db = `<div class="why">What should the robot do for this mood - now <b>and</b> for later meetings?</div>
      <div class="formula">Q(s,a) = R(s,a) + γ Σ_s' T(s'|s,a) V(s')   (value iteration, γ = 0.8)
mood uncertain → a* = argmax_a Σ_s b(s)·Q(s,a)</div>`;
    if (D) {
      const vals = Object.values(D.scores), lo = Math.min(...vals) - 2, hi = Math.max(...vals);
      db += `<div class="bars">${Object.entries(D.scores).map(([k, v]) => bar(k, v - lo, hi - lo, { hot: k === D.action, text: v.toFixed(1) })).join("")}</div>
        <div class="kv">→ chosen: <b>${D.action}</b></div>
        <table class="pol"><tr><td class="muted">if surely…</td>${Object.keys(D.policy).map((s) => `<td>${s}</td>`).join("")}</tr>
        <tr><td class="muted">best action</td>${Object.values(D.policy).map((a) => `<td>${a}</td>`).join("")}</tr></table>`;
    } else db += `<div class="muted">Waiting for the robot to meet a group.</div>`;
    parts.push(card(ALGO[5], on("mdp"), db));
    // Naive Bayes
    const N = ex.nb;
    let nb = `<div class="why">Students type in their own words (English or Russian). What do they want?</div>
      <div class="formula">P(intent | words) ∝ P(intent) · Π P(word | intent)   (Laplace smoothing, log space)</div>`;
    if (N) {
      nb += `<div class="kv">“<b>${esc(N.text)}</b>”</div><div class="tokens">${N.words.map((w) => `<span>${esc(w)}</span>`).join("") || '<span class="muted">no known words</span>'}</div>
        <div class="bars">${N.probs.slice(0, 5).map(([c, p]) => bar(c, p, 1, { hot: c === N.intent, text: pct(p) })).join("")}</div>
        <div class="kv">answer: ${esc(N.reply)}</div>`;
    } else nb += `<div class="muted">Type a question below, or wait for a student to ask one.</div>`;
    parts.push(card(ALGO[6], on("nb"), nb));
    $("explain").innerHTML = parts.join("");
  }
  function buildPipeline() {
    $("pipeline").innerHTML = ALGO.map((a, i) => `${i ? '<span class="arrow">›</span>' : ""}<button class="chip" id="chip-${a.key}" data-k="${a.key}">${a.name}<small>${a.wk}</small></button>`).join("");
    for (const a of ALGO) $("chip-" + a.key).onclick = () => {
      setTab("explain");
      const c = document.getElementById("card-" + a.key);
      if (c) c.scrollIntoView({ behavior: "smooth", block: "start" });
    };
  }
  function setTab(name) {
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("on", t.dataset.tab === name));
    $("explain").hidden = name !== "explain";
    $("log").hidden = name !== "log";
    if (name === "log") $("log").scrollTop = $("log").scrollHeight;
  }
  document.querySelectorAll(".tab").forEach((t) => { t.onclick = () => setTab(t.dataset.tab); });

  // ----------------------------------------------------------------- render
  function frame() {
    requestAnimationFrame(frame);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    cssW = canvas.clientWidth; cssH = canvas.clientHeight;
    if (canvas.width !== Math.round(cssW * dpr) || canvas.height !== Math.round(cssH * dpr)) {
      canvas.width = Math.round(cssW * dpr); canvas.height = Math.round(cssH * dpr);
      overlay.width = canvas.width; overlay.height = canvas.height;
    }
    if (!MAP || !cur) return;
    const span = Math.max(60, cur.arrive - prev.arrive);
    const t = clamp((performance.now() - cur.arrive) / span, 0, 1);

    // robot position + heading (smooth)
    const rr = lerp(prev.robot.r, cur.robot.r, t), rc = lerp(prev.robot.c, cur.robot.c, t);
    let dh = (cur.heading ?? 0) - heading;
    while (dh > Math.PI) dh -= 2 * Math.PI;
    while (dh < -Math.PI) dh += 2 * Math.PI;
    heading += dh * 0.15;

    if (cam.follow) {
      cam.target[0] = lerp(cam.target[0], rc, 0.08); cam.target[2] = lerp(cam.target[2], rr, 0.08);
    }
    const eye = [cam.target[0] + cam.dist * Math.cos(cam.pitch) * Math.sin(cam.yaw), cam.dist * Math.sin(cam.pitch),
      cam.target[2] + cam.dist * Math.cos(cam.pitch) * Math.cos(cam.yaw)];
    const up = cam.pitch > 1.45 ? [-Math.sin(cam.yaw), 0, -Math.cos(cam.yaw)] : [0, 1, 0];
    viewMVP = mul(perspective(0.75, cssW / cssH, 0.5, 400), lookAt(eye, cam.target, up));

    // dynamic mesh: students, robot, paths
    const m = new Mesh(), a = new Mesh();
    const groups = MAP.group_order.map((gname) => hex(MAP.groups[gname]));
    for (const s of cur.students) {
      const p = prev.map.get(s[0]) || s;
      const z = lerp(p[1], s[1], t), x = lerp(p[2], s[2], t);
      const seated = s[4] <= 1;
      const h = seated ? 0.36 : 0.5;
      m.prism(x, z, 0.17, 0, h, groups[s[3]] || groups[0], null, 7);
      m.prism(x, z, 0.1, h + 0.02, h + 0.2, C.skin, C.hair, 6);
    }
    drawCat(m, [rc, 0, rr], heading, cur.robot.interacting);
    if ($("lyRoutes").checked) {
      ribbon(m, cur.plan, C.plan, true);
      ribbon(m, cur.guide, C.guide, false);
    }
    // ---- explanation layers (transparent) ----
    if ($("lyVision").checked) {
      const v = cur.vision;
      for (let i = 0; i < v.length; i += 2) tile(a, v[i], v[i + 1], 0.012, C.vision, 0.3);
    }
    if ($("lyBelief").checked && cur.explain.bayes) {
      for (const z of cur.explain.bayes.zones) {
        const room = MAP.rooms[z.room];
        if (!room) continue;
        for (const [r, c] of room.gather) tile(a, r, c, 0.018, C.belief, 0.08 + 0.5 * z.p);
      }
    }
    if ($("lyAstar").checked && astarCells.length) {
      const fade = clamp(1 - (performance.now() - astarRecv) / 7000, 0, 1);
      if (fade > 0) for (const [r, c] of astarCells) tile(a, r, c, 0.024, C.astar, 0.42 * fade, 0.36);
    }
    for (const s of cur.students) if (cur.seenSet.has(s[0])) {       // students the camera noticed
      const p = prev.map.get(s[0]) || s;
      disc(a, lerp(p[2], s[2], t), lerp(p[1], s[1], t), 0.34, C.seen, 0.75, 0.03);
    }
    if (cur.robot.interacting) disc(a, rc, rr, MAP.reach, hex("#f28c28"), 0.22);

    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniformMatrix4fv(uMVP, false, new Float32Array(viewMVP));
    gl.disable(gl.BLEND); gl.depthMask(true);
    draw(staticBuf);
    upload(dynBuf, m, gl.DYNAMIC_DRAW); draw(dynBuf);
    if (a.v.length) {
      gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
      upload(alphaBuf, a, gl.DYNAMIC_DRAW); draw(alphaBuf);
      gl.depthMask(true); gl.disable(gl.BLEND);
    }
    t0 = t;
    drawOverlay(dpr, rr, rc);
  }

  function drawCat(m, o, h, talking) {
    const S = 1.4;                                   // robot is drawn a bit bigger so it is easy to spot
    const ob = (u0, u1, y0, y1, w0, w1, col) => m.obox(o, h, u0 * S, u1 * S, y0 * S, y1 * S, w0 * S, w1 * S, col);
    const bob = talking ? Math.sin(performance.now() / 180) * 0.03 : 0;
    ob(-0.3, 0.3, 0.02, 0.12, -0.34, 0.34, C.catDark);                          // wheel base
    ob(-0.26, 0.26, 0.12, 0.5, -0.32, 0.2, C.catBody);                           // body
    const P0 = ob(-0.25, 0.25, 0.47 + bob, 0.84 + bob, 0.02, 0.42, C.catHead);   // head
    const P = (u, y, w) => P0(u * S, y * S, w * S);
    for (const s of [-1, 1]) {                                                    // ears + eyes
      const b0 = P(s * 0.08, 0.84 + bob, 0.14), b1 = P(s * 0.24, 0.84 + bob, 0.14), b2 = P(s * 0.16, 0.84 + bob, 0.3);
      const tip = P(s * 0.17, 1.06 + bob, 0.2);
      m.tri(b0, b1, tip, shade(C.catBody, [0, 0.6, 0.8])); m.tri(b1, b2, tip, shade(C.catBody, [0.8, 0.6, 0]));
      m.tri(b2, b0, tip, shade(C.catBody, [-0.8, 0.6, 0])); m.tri(b0, b2, tip, shade(C.catPink, [0, 0.6, -0.8]));
      ob(s * 0.12 - 0.035, s * 0.12 + 0.035, 0.66 + bob, 0.74 + bob, 0.42, 0.445, C.catDark);
    }
    ob(-0.03, 0.03, 0.6 + bob, 0.64 + bob, 0.42, 0.45, C.catPink);                // nose
    const wag = Math.sin(performance.now() / 260) * 0.08;
    ob(-0.04 + wag, 0.04 + wag, 0.38, 0.92, -0.42, -0.32, C.catBody);            // tail
  }
  function ribbon(m, path, col, dashed) {
    if (!path || path.length < 2) return;
    for (let i = 0; i < path.length - 1; i++) {
      if (dashed && i % 2) continue;
      const [r0, c0] = path[i], [r1, c1] = path[i + 1];
      const dx = c1 - c0, dz = r1 - r0, w = 0.09;
      const nx = -dz * w, nz = dx * w;
      m.quad([c0 + nx, 0.04, r0 + nz], [c1 + nx, 0.04, r1 + nz], [c1 - nx, 0.04, r1 - nz], [c0 - nx, 0.04, r0 - nz], col, null);
    }
  }
  function disc(m, cx, cz, r, col, alpha, y = 0.03) {
    const n = 32;
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * Math.PI * 2, a1 = ((i + 1) / n) * Math.PI * 2;
      m.tri([cx, y, cz], [cx + Math.cos(a1) * r, y, cz + Math.sin(a1) * r], [cx + Math.cos(a0) * r, y, cz + Math.sin(a0) * r], col, alpha);
    }
  }
  function tile(m, r, c, y, col, alpha, half = 0.5) {
    m.quad([c - half, y, r - half], [c + half, y, r - half], [c + half, y, r + half], [c - half, y, r + half], col, null, alpha);
  }

  function project(x, y, z) {
    const p = xform(viewMVP, [x, y, z]);
    if (p[3] <= 0.1) return null;
    return [(p[0] / p[3] * 0.5 + 0.5) * cssW, (1 - (p[1] / p[3] * 0.5 + 0.5)) * cssH, p[3]];
  }
  let t0 = 0;
  function drawOverlay(dpr, rr, rc) {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    const zoom = clamp(70 / cam.dist, 0.6, 1.6);
    for (const L of labelSpots) {
      const p = project(L.x, L.y ?? 0.05, L.z);
      if (!p) continue;
      if (L.misc) {
        ctx.font = `italic ${Math.round(11 * zoom)}px Segoe UI, sans-serif`;
        ctx.fillStyle = "rgba(200,215,255,.85)"; ctx.fillText(L.name, p[0], p[1]);
        continue;
      }
      ctx.font = `700 ${Math.round((L.office ? 10 : L.toilet ? 12 : 14) * zoom)}px Segoe UI, sans-serif`;
      ctx.fillStyle = L.office ? "rgba(70,80,100,.75)" : L.toilet ? "rgba(20,90,80,.95)" : "rgba(28,45,95,.9)";
      ctx.fillText(L.title, p[0], p[1] - (L.toilet ? 0 : 6) * zoom);
      const info = cur.labels[L.name];
      if (info) {
        ctx.font = `${Math.round(10 * zoom)}px Segoe UI, sans-serif`;
        ctx.fillStyle = "rgba(28,45,95,.85)";
        ctx.fillText(info.length > 30 ? info.slice(0, 29) + "…" : info, p[0], p[1] + 9 * zoom);
      }
    }
    // belief labels over the halls
    if ($("lyBelief").checked && cur.explain.bayes) for (const z of cur.explain.bayes.zones) {
      const room = MAP.rooms[z.room];
      if (!room || !room.spot) continue;
      const p = project(room.spot[1], 0.6, room.spot[0]);
      if (!p) continue;
      const txt = `P ${Math.round(z.p * 100)}%`;
      ctx.font = "700 11px Segoe UI, sans-serif";
      const w = ctx.measureText(txt).width + 10;
      ctx.fillStyle = z.p >= 0.5 ? "rgba(255,122,61,.92)" : "rgba(60,72,120,.9)";
      ctx.beginPath(); ctx.roundRect ? ctx.roundRect(p[0] - w / 2, p[1] + 10, w, 16, 5) : ctx.rect(p[0] - w / 2, p[1] + 10, w, 16); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.fillText(txt, p[0], p[1] + 18.5);
    }
    // numbered tour stops (order chosen by hill climbing)
    if ($("lyRoutes").checked) for (const stop of cur.tour) {
      const room = MAP.rooms[stop.room];
      if (!room || !room.spot) continue;
      const p = project(room.spot[1], 1.3, room.spot[0]);
      if (!p) continue;
      ctx.beginPath(); ctx.arc(p[0], p[1], 11, 0, Math.PI * 2);
      ctx.fillStyle = "#f28c28"; ctx.fill();
      ctx.lineWidth = 2; ctx.strokeStyle = "#fff"; ctx.stroke();
      ctx.font = "700 12px Segoe UI, sans-serif"; ctx.fillStyle = "#fff"; ctx.fillText(stop.n, p[0], p[1] + 0.5);
    }
    // speech bubble above the student who is asking
    const sb = $("sbubble");
    let shown = false;
    if (cur.student_bubble) {
      const s = cur.students.find((x) => x[0] === cur.student_bubble.sid);
      if (s) {
        const p0 = prev.map.get(s[0]) || s;
        const ps = project(lerp(p0[2], s[2], t0), 0.95, lerp(p0[1], s[1], t0));
        if (ps) {
          sb.hidden = false; shown = true;
          sb.innerHTML = `<b>🎓 asks:</b> ${esc(cur.student_bubble.text)}`;
          sb.style.left = clamp(ps[0], 140, cssW - 140) + "px"; sb.style.top = Math.max(ps[1] - 6, 90) + "px";
        }
      }
    }
    if (!shown) sb.hidden = true;
    // speech bubble above the cat
    const b = $("bubble");
    const p = project(rc, 1.6, rr);
    if (cur.bubble && p) {
      b.hidden = false; b.textContent = cur.bubble;
      b.style.left = clamp(p[0], 170, cssW - 170) + "px"; b.style.top = Math.max(p[1] - 6, 90) + "px";
      if (!sb.hidden) {   // keep the two bubbles from covering each other
        const r1 = b.getBoundingClientRect(), r2 = sb.getBoundingClientRect();
        if (r1.left < r2.right && r2.left < r1.right && r1.top < r2.bottom && r2.top < r1.bottom)
          b.style.top = (parseFloat(sb.style.top) - r2.height - 14) + "px";
      }
    } else b.hidden = true;
  }

  function fail(html) { const e = $("error"); e.innerHTML = html; e.hidden = false; }

  // -------------------------------------------------------------- controls
  $("askForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = $("askInput").value.trim();
    if (!text) return;
    $("askInput").value = "";
    await fetch("/api/ask", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) });
    setTab("explain");
    setTimeout(() => { const c = document.getElementById("card-nb"); if (c) c.scrollIntoView({ behavior: "smooth", block: "nearest" }); }, 500);
  });
  const showSpeed = () => { $("speed").textContent = "×" + speed; };
  function setPaused(v) {
    paused = v; $("btnPause").textContent = paused ? "Play" : "Pause";
    if (!paused) $("pauseBanner").hidden = true;
  }
  $("btnPause").onclick = () => setPaused(!paused);
  $("btnSlower").onclick = () => { speed = Math.max(1, Math.round(speed / 2)); showSpeed(); };
  $("btnFaster").onclick = () => { speed = Math.min(240, speed * 2); showSpeed(); };
  $("btnNext").onclick = () => fetch("/api/control", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "next_break" }) });
  $("btnFollow").onclick = () => { cam.follow = !cam.follow; $("btnFollow").classList.toggle("on", cam.follow); if (cam.follow) cam.dist = 24; };
  $("btnTop").onclick = () => resetView(true);
  $("btnReset").onclick = () => resetView(false);
  showSpeed();

  // ----------------------------------------------------------------- start
  buildPipeline();
  fetch("/api/map").then((r) => r.json()).then((map) => {
    buildStatic(map); resetView(false); poll(); requestAnimationFrame(frame);
  }).catch(() => fail("Cannot reach the simulation.<br>Start it with <b>python server3d.py</b> and open <b>http://localhost:8000</b>"));

  // for automated screenshots / tests
  window.mysyq = { state: () => cur, ask: (text) => fetch("/api/ask", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) }), cam, setSpeed: (s) => { speed = s; showSpeed(); }, resetView, setPaused, setTab };
})();
